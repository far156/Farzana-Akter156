package com.example.colorchoser;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button grn1,grn3,grn5,grn7,grn9,red2,red4,red6,red8,result;
    int green_count=0,red_count=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        grn1=findViewById(R.id.green1);
        grn3=findViewById(R.id.green3);
        grn5=findViewById(R.id.green5);
        grn7=findViewById(R.id.green7);
        grn9=findViewById(R.id.green9);
        red2=findViewById(R.id.red2);
        red4=findViewById(R.id.red4);
        red6=findViewById(R.id.red6);
        red8=findViewById(R.id.red8);
        result=findViewById(R.id.result_btn);


        grn1.setOnClickListener(this);
        grn3.setOnClickListener(this);
        grn5.setOnClickListener(this);
        grn7.setOnClickListener(this);
        grn9.setOnClickListener(this);
        red2.setOnClickListener(this);
        red4.setOnClickListener(this);
        red6.setOnClickListener(this);
        red8.setOnClickListener(this);
        result.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId()==R.id.green1){
            green_count++;
        }
        if(view.getId()==R.id.green3){
            green_count++;
        }
        if(view.getId()==R.id.green5){
            green_count++;
        }
        if(view.getId()==R.id.green7){
            green_count++;
        }
        if(view.getId()==R.id.green9){
            green_count++;
        }

        if(view.getId()==R.id.red2){
            red_count++;
        }
        if(view.getId()==R.id.red4){
            red_count++;
        }
        if(view.getId()==R.id.red6){
            red_count++;
        }
        if(view.getId()==R.id.red8){
            red_count++;
        }

        if(view.getId()==R.id.result_btn){
            String green=Integer.toString(green_count);
            String red=Integer.toString(red_count);
            Bundle b = new Bundle();
            b.putStringArray("key", new String[]{green, red});
            Intent i=new Intent(this, MainActivity2.class);
            i.putExtras(b);
            startActivity(i);
        }

    }
}